# 言語化トレーニングアプリ - デプロイ手順

## 必要なもの
- Windows PC
- Anthropic APIキー（https://console.anthropic.com で取得）

---

## 手順（30分くらい）

### ① Node.js をインストール
1. https://nodejs.org を開く
2. 「LTS」と書いてある緑のボタンでダウンロード
3. インストーラーを実行（全部「Next」でOK）

### ② Vercel CLI をインストール
コマンドプロンプトを開いて（Windowsキー → 「cmd」と入力 → Enter）：
```
npm install -g vercel
```

### ③ このフォルダをVercelにデプロイ
コマンドプロンプトで、このフォルダに移動して：
```
cd C:\Users\あなたのユーザー名\Downloads\gengouka-app
vercel
```

※ 初回はGitHubかGoogleでログインを求められます

### ④ APIキーを設定
デプロイ後、Vercelのダッシュボード（https://vercel.com）で：
1. プロジェクトを選択
2. Settings → Environment Variables
3. 以下を追加：
   - Name: `ANTHROPIC_API_KEY`
   - Value: `sk-ant-...`（あなたのAPIキー）
4. Save → **Deployments** から「Redeploy」

### ⑤ 完成！
表示されたURL（例：`https://gengouka-app.vercel.app`）を友人に共有するだけ！

---

## 費用について
- Vercel: 無料プランで十分
- Anthropic API: 使った分だけ（1回のセッション約1〜2円程度）
